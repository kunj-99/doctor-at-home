package com.infowave.thedoctorathomeuser.network;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Process-wide Volley queue. Volley manages cache and multiple network worker
 * threads internally; reusing this queue prevents duplicate thread pools and
 * disk caches when several screens refresh at the same time.
 */
public final class VolleySingleton {

    private static volatile VolleySingleton instance;
    private final RequestQueue requestQueue;

    private VolleySingleton(Context context) {
        requestQueue = Volley.newRequestQueue(context.getApplicationContext());
    }

    public static VolleySingleton getInstance(Context context) {
        if (instance == null) {
            synchronized (VolleySingleton.class) {
                if (instance == null) {
                    instance = new VolleySingleton(context);
                }
            }
        }
        return instance;
    }

    public RequestQueue getRequestQueue() {
        return requestQueue;
    }

    public <T> void add(Request<T> request) {
        requestQueue.add(request);
    }
}
