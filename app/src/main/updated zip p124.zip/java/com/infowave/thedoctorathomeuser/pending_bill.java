package com.infowave.thedoctorathomeuser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.phonepe.intent.sdk.api.PhonePeKt;
import com.infowave.thedoctorathomeuser.network.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class pending_bill extends AppCompatActivity {

    private static final String TAG = "PendingBill";

    // Turn on/off logs from one place
    private static final boolean DBG = true;

    // Pricing/config
    private static double APPOINTMENT_CHARGE;
    private static double DEPOSIT;
    private static double PER_KM_CHARGE;
    private static double GST_PERCENT;
    private static double FREE_DISTANCE_KM;

    // State flags
    private boolean cfgLoaded = false;
    private boolean chargeLoaded = false;
    private boolean distanceReady = false;

    // Computed amounts
    private double consultingFee;
    private double distanceKm = 0.0;
    private double distanceCharge = 0.0;
    private double gstAmount = 0.0;
    private double finalCost = 0.0;          // rupees (double for math)
    private long   finalPayRupees = 0L;      // rupees (rounded up for display)

    // Locations
    private double docLat = 0.0, docLng = 0.0, userLat = 0.0, userLng = 0.0;

    // Appointment/person fields
    private String patientName, patientAge, patientGender, patientProblem, patientAddress, doctorId, doctorName, status;
    private String selectedPaymentMethod = "Online";
    private String patientId, pincode, googleMapsLink = "";

    // Vet case
    private int isVetCase = 0;
    private String animalName, animalGender, animalBreed, animalAge, vaccinationName;
    private String animalCategoryId = "";
    private String vaccinationId   = "";

    // NEW: vaccine price from previous activity
    private double vaccinationPrice = 0.0;

    // ─── Reservation token (from DoctorAdapter / VetDoctorsAdapter) ──────────
    /** Token from reserve_doctor.php — must be sent to save_appointment.php */
    private String reservationToken = "";
    // Patient ID is loaded from SharedPrefs at onCreate, but also forwarded in intent for cross-check
    // patientId variable already declared below and loaded from SharedPrefs (authoritative)

    // ─── Lock-release safety flags ────────────────────────────────────────────
    /** True once user commits to payment (PhonePe or offline pay button pressed) */
    private boolean paymentStarted          = false;
    /** True while save_appointment.php HTTP call is in flight */
    private boolean appointmentSaveInProgress = false;
    /** True after server confirms appointment_id successfully */
    private boolean appointmentConfirmed    = false;
    /** True after we have already sent a release request (prevent duplicate) */
    private boolean lockReleased            = false;

    // UI
    private Button payButton, btnOnlinePayment, btnOfflinePayment, btnRechargeWallet;
    private TextView tvBillDate, tvBillTime, tvBillPatientName, tvBillDoctorName;
    private TextView tvAppointmentCharge, tvDeposit, tvConsultingFeeValue, tvDistanceKmValue, tvDistanceChargeValue, tvGstValue, tvTotalPaidValue, tvWalletBalance;
    private LinearLayout rowAnimalName, rowAnimalAge, rowAnimalGender, rowAnimalBreed, rowAnimalVaccination;
    private TextView tvAnimalName, tvAnimalAge, tvAnimalGender, tvAnimalBreed, tvAnimalVaccination;
    private View depositRow;
    private View depositLabelView;

    // NEW: vaccination price row + value
    private View rowVaccinationPrice;
    private TextView tvVaccinationPriceValue;

    // PhonePe
    private final String ppCreateOrderUrl = ApiConfig.endpoint("phonepe/public/create_order.php");
    private final String ppStatusUrl      = ApiConfig.endpoint("phonepe/public/check_status.php");

    // NEW: UPI verify URL (per two-block rule above)
    private final String upiVerifyUrl     = ApiConfig.endpoint("verify_upi.php");
    private final String bookingQuoteUrl  = ApiConfig.endpoint("get_booking_quote.php");

    private String ppMerchantOrderId;
    private String bookingQuoteToken = "";
    private ActivityResultLauncher<Intent> ppCheckoutLauncher;

    // Wallet
    private double walletBalance = 0.0;
    private final Handler walletHandler = new Handler();
    private Runnable walletRunnable;
    private TextView tvPricePerKm;

    private enum DepositMode { NONE, WALLET, BILL }
    private DepositMode lastConfirmedDepositMode = DepositMode.NONE;

    // NEW: hold the verified UPI so we can store it in payment_history later
    private String enteredUpiId = "";

    // Lifecycle guard
    private boolean isDestroyedOrFinishing = false;

    /* -------------------- LOG HELPERS -------------------- */

    private void d(String msg) {
        if (DBG) Log.d(TAG, msg);
    }

    private void w(String msg) {
        if (DBG) Log.w(TAG, msg);
    }

    private void e(String msg, Throwable t) {
        if (DBG) Log.e(TAG, msg, t);
    }

    private static String fmt2(double v) {
        return String.format(Locale.getDefault(), "%.2f", v);
    }

    private static String fmt1(double v) {
        return String.format(Locale.getDefault(), "%.1f", v);
    }

    private static String safe(String s) {
        return (s == null) ? "null" : s;
    }

    // Masks UPI like "ku***@bank"
    private static String maskUpi(String vpa) {
        if (vpa == null) return "null";
        String s = vpa.trim();
        int at = s.indexOf('@');
        if (at <= 0) return "***";
        String left = s.substring(0, at);
        String right = s.substring(at);
        if (left.length() <= 2) return "**" + right;
        return left.substring(0, 2) + "***" + right;
    }

    // Do not print Google Directions API key in logs
    private void logDirectionsRequest(double oLat, double oLng, double dLat, double dLng) {
        d("Directions request (NO KEY LOGGED): origin=" + oLat + "," + oLng + " destination=" + dLat + "," + dLng);
    }

    // Centralized state dump for price/location/distance
    private void logBillingState(String where) {
        d("=== BILLING STATE @ " + where + " ===");
        d("Flags: cfgLoaded=" + cfgLoaded + ", chargeLoaded=" + chargeLoaded + ", distanceReady=" + distanceReady);
        d("Payment: selectedPaymentMethod=" + safe(selectedPaymentMethod) + ", lastConfirmedDepositMode=" + lastConfirmedDepositMode);
        d("User: patientId=" + safe(patientId) + ", doctorId=" + safe(doctorId) + ", pincode=" + safe(pincode));
        d("Vet: isVetCase=" + isVetCase
                + ", animalCategoryId=" + safe(animalCategoryId)
                + ", vaccinationId=" + safe(vaccinationId)
                + ", vaccinationName=" + safe(vaccinationName)
                + ", vaccinationPrice=" + fmt2(vaccinationPrice));
        d("Locations: userLatLng=" + userLat + "," + userLng
                + " docLatLng=" + docLat + "," + docLng
                + " mapLink=" + safe(googleMapsLink));
        d("Config: FREE_DISTANCE_KM=" + fmt2(FREE_DISTANCE_KM)
                + ", PER_KM_CHARGE=" + fmt2(PER_KM_CHARGE)
                + ", DEPOSIT=" + fmt2(DEPOSIT)
                + ", GST_PERCENT=" + fmt2(GST_PERCENT)
                + ", APPOINTMENT_CHARGE=" + fmt2(APPOINTMENT_CHARGE));
        d("Distance: distanceKm=" + fmt2(distanceKm) + ", distanceCharge=" + fmt2(distanceCharge));
        d("Amounts: consultingFee=" + fmt2(consultingFee)
                + ", gstAmount=" + fmt2(gstAmount)
                + ", finalCost=" + fmt2(finalCost)
                + ", finalPayRupees=" + finalPayRupees);
        d("Wallet: walletBalance=" + fmt2(walletBalance));
        d("=== END STATE ===");
    }

    @Override
    protected void onResume() {
        super.onResume();
        isDestroyedOrFinishing = false;
        d("onResume()");
        fetchWalletBalance();
        if (cfgLoaded && chargeLoaded && distanceReady) recomputeTotalsAndUI();
        if (walletRunnable != null) {
            walletHandler.postDelayed(walletRunnable, 30000);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_bill);
        setupSystemBarScrims();

        d("onCreate() started");

        // PhonePe launcher
        ppCheckoutLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    d("PhonePe activity result received. resultCode=" + result.getResultCode());
                    if (ppMerchantOrderId != null) {
                        d("Triggering PhonePe status check for merchantOrderId=" + ppMerchantOrderId);
                        checkPhonePeStatus(ppMerchantOrderId);
                    } else {
                        w("PhonePe result received but ppMerchantOrderId is null");
                    }
                }
        );

        // Logged-in user
        SharedPreferences sp = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        patientId = sp.getString("patient_id", "");
        d("Loaded patientId from prefs: " + safe(patientId));

        if (patientId == null || patientId.isEmpty()) {
            Toast.makeText(this, "Sorry, we could not identify your profile. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Show loader for initial async work
        if (!isFinishing() && !isDestroyed()) loaderutil.showLoader(this);

        // Intent extras
        Intent intent = getIntent();
        patientName   = intent.getStringExtra("patient_name");
        patientAge    = String.valueOf(intent.getIntExtra("age", 0));
        patientGender = intent.getStringExtra("gender");
        patientProblem= intent.getStringExtra("problem");
        patientAddress= intent.getStringExtra("address");
        doctorId      = intent.getStringExtra("doctor_id");
        doctorName    = intent.getStringExtra("doctorName");
        status        = intent.getStringExtra("appointment_status");
        pincode       = intent.getStringExtra("pincode");

        // Vet extras
        animalName       = intent.getStringExtra("animal_name");
        animalGender     = intent.getStringExtra("animal_gender");
        animalBreed      = intent.getStringExtra("animal_breed");
        animalAge        = String.valueOf(intent.getIntExtra("animal_age", 0));
        vaccinationName  = intent.getStringExtra("vaccination_name");
        animalCategoryId = intent.getStringExtra("animal_category_id");
        vaccinationId    = intent.getStringExtra("vaccination_id");
        isVetCase        = intent.getIntExtra("is_vet_case", 0);

        // NEW: vaccination price
        vaccinationPrice = intent.getDoubleExtra("vaccination_price", 0.0);

        // ─── Reservation token (forwarded from adapter through form activity) ───
        reservationToken = intent.getStringExtra("reservation_token") != null
                         ? intent.getStringExtra("reservation_token") : "";

        if (animalCategoryId == null) animalCategoryId = "";
        if (vaccinationId == null)    vaccinationId = "";

        d("Intent extras:"
                + " patientName=" + safe(patientName)
                + ", patientAge=" + safe(patientAge)
                + ", patientGender=" + safe(patientGender)
                + ", status(raw)=" + safe(status)
                + ", doctorId=" + safe(doctorId)
                + ", doctorName=" + safe(doctorName)
                + ", pincode=" + safe(pincode)
                + ", isVetCase=" + isVetCase
                + ", animalName=" + safe(animalName)
                + ", vaccinationName=" + safe(vaccinationName)
                + ", vaccinationPrice=" + fmt2(vaccinationPrice));

        if (doctorId == null || doctorId.isEmpty()) {
            loaderutil.hideLoader();
            Toast.makeText(this, "Sorry, we could not find the doctor information. Please try again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if ("Request for visit".equals(status))      status = "Requested";
        else if ("Book Appointment".equals(status))  status = "Confirmed";

        d("Normalized status=" + safe(status));

        // User location for map link
        userLat = intent.getDoubleExtra("latitude", 0.0);
        userLng = intent.getDoubleExtra("longitude", 0.0);
        if (userLat != 0.0 && userLng != 0.0) {
            googleMapsLink = "https://www.google.com/maps/search/?api=1&query=" + userLat + "," + userLng;
        }
        d("User location: userLatLng=" + userLat + "," + userLng + " mapLink=" + safe(googleMapsLink));

        // Bind UI
        tvBillPatientName     = findViewById(R.id.tv_bill_patient_name);
        tvBillDoctorName      = findViewById(R.id.tv_bill_doctor_name);
        tvBillDate            = findViewById(R.id.tv_bill_date);
        tvBillTime            = findViewById(R.id.tv_bill_time);
        tvWalletBalance       = findViewById(R.id.tv_wallet_balance);
        tvAppointmentCharge   = findViewById(R.id.tv_appointment_charge);
        tvDeposit             = findViewById(R.id.tv_deposit);
        tvConsultingFeeValue  = findViewById(R.id.tv_consultation_fee);
        tvDistanceKmValue     = findViewById(R.id.tv_distance_km_value);
        tvDistanceChargeValue = findViewById(R.id.tv_distance_charge_value);
        tvPricePerKm          = findViewById(R.id.price_km);

        tvGstValue            = findViewById(R.id.tv_gst_value);
        tvTotalPaidValue      = findViewById(R.id.tv_total_paid_value);
        btnOnlinePayment      = findViewById(R.id.btn_online_payment);
        btnOfflinePayment     = findViewById(R.id.btn_offline_payment);
        btnRechargeWallet     = findViewById(R.id.btn_recharge_wallet);
        payButton             = findViewById(R.id.pay_button);

        rowAnimalName        = findViewById(R.id.row_animal_name);
        rowAnimalAge         = findViewById(R.id.row_animal_age);
        rowAnimalGender      = findViewById(R.id.row_animal_gender);
        rowAnimalBreed       = findViewById(R.id.row_animal_breed);
        rowAnimalVaccination = findViewById(R.id.row_animal_vaccination);
        tvAnimalName         = findViewById(R.id.tv_bill_animal_name);
        tvAnimalAge          = findViewById(R.id.tv_bill_animal_age);
        tvAnimalGender       = findViewById(R.id.tv_bill_animal_gender);
        tvAnimalBreed        = findViewById(R.id.tv_bill_animal_breed);
        tvAnimalVaccination  = findViewById(R.id.tv_bill_animal_vaccination);

        // NEW: vaccination price row + value
        rowVaccinationPrice     = findViewById(R.id.row_vaccination_price);
        tvVaccinationPriceValue = findViewById(R.id.tv_vaccination_price_value);

        depositRow = tvDeposit != null ? (View) tvDeposit.getParent() : null;
        @SuppressLint("DiscouragedApi") int labelId = getResources().getIdentifier("tv_deposit_label", "id", getPackageName());
        depositLabelView = (labelId != 0) ? findViewById(labelId) : null;
        hideDepositRow();

        // Header info
        setTextOrDash(tvBillPatientName, isVetCase == 1 ? animalName : patientName);
        setTextOrDash(tvBillDoctorName, doctorName);
        String curDate = new SimpleDateFormat("dd MMMM, yyyy", Locale.getDefault()).format(new Date());
        String curTime = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
        tvBillDate.setText(curDate);
        tvBillTime.setText(curTime);

        d("Header set: date=" + curDate + " time=" + curTime);

        // Vet rows visibility
        if (isVetCase == 1) {
            setRowVisibility(rowAnimalName,        true); setTextOrDash(tvAnimalName, animalName);
            setRowVisibility(rowAnimalAge,         true); setTextOrDash(tvAnimalAge, animalAge);
            setRowVisibility(rowAnimalGender,      true); setTextOrDash(tvAnimalGender, animalGender);
            setRowVisibility(rowAnimalBreed,       true); setTextOrDash(tvAnimalBreed, animalBreed);
            setRowVisibility(rowAnimalVaccination, true); setTextOrDash(tvAnimalVaccination, vaccinationName);
        } else {
            setRowVisibility(rowAnimalName,        false);
            setRowVisibility(rowAnimalAge,         false);
            setRowVisibility(rowAnimalGender,      false);
            setRowVisibility(rowAnimalBreed,       false);
            setRowVisibility(rowAnimalVaccination, false);
        }

        // NEW: vaccination price line
        if (isVetCase == 1 && vaccinationPrice > 0.0) {
            setRowVisibility(rowVaccinationPrice, true);
            tvVaccinationPriceValue.setText("₹ " + (int) Math.round(vaccinationPrice));
        } else {
            setRowVisibility(rowVaccinationPrice, false);
        }

        // Buttons default
        setButtonNeutralState();
        selectedPaymentMethod = "Online";
        stylePaymentButtons();
        disablePayButton();

        d("Initial paymentMethod=" + selectedPaymentMethod);

        // Load one server-authoritative quote for the initial bill preview.
        fetchAuthoritativeBookingQuote(false);

        // Wallet polling (lifecycle-aware)
        walletRunnable = () -> {
            if (!isDestroyedOrFinishing && !isFinishing() && !isDestroyed()) {
                d("Wallet polling tick...");
                fetchWalletBalance();
                walletHandler.postDelayed(walletRunnable, 30000);
            }
        };
        walletHandler.postDelayed(walletRunnable, 30000);

        btnOfflinePayment.setOnClickListener(v -> {
            selectedPaymentMethod = "Offline";
            d("Selected payment method -> Offline");
            stylePaymentButtons();
            if (walletBalance < DEPOSIT) {
                Toast.makeText(this, "Offline booking के लिए Wallet में कम से कम ₹" + (int) DEPOSIT + " चाहिए.", Toast.LENGTH_SHORT).show();
                w("Offline selected but walletBalance(" + fmt2(walletBalance) + ") < DEPOSIT(" + fmt2(DEPOSIT) + ")");
            }
            recomputeTotalsAndUI();
        });

        btnOnlinePayment.setOnClickListener(v -> {
            selectedPaymentMethod = "Online";
            d("Selected payment method -> Online");
            stylePaymentButtons();
            recomputeTotalsAndUI();
        });

        btnRechargeWallet.setOnClickListener(v -> startActivity(new Intent(pending_bill.this, payments.class)));

        // payButton click → show dialog with UPI input + verify before proceeding
        payButton.setOnClickListener(v -> {
            d("Pay button clicked. current totalPayRupees=" + finalPayRupees + ", finalCost=" + fmt2(finalCost));
            logBillingState("payButtonClicked");
            showConfirmWithUpiDialog();
        });

        logBillingState("onCreate_end");
    }

    @Override
    protected void onPause() {
        super.onPause();
        d("onPause()");
        if (walletHandler != null && walletRunnable != null) {
            walletHandler.removeCallbacks(walletRunnable);
        }
        loaderutil.hideLoader();
    }

    @Override
    protected void onStop() {
        super.onStop();
        d("onStop()");
        loaderutil.hideLoader();
    }

    @Override
    protected void onDestroy() {
        d("onDestroy()");
        isDestroyedOrFinishing = true;
        if (walletHandler != null && walletRunnable != null) {
            walletHandler.removeCallbacks(walletRunnable);
        }
        loaderutil.hideLoader();
        // Only release lock if finishing before payment ever started
        // (e.g., user backs out, OS eviction). Never releases after payment committed.
        if (isFinishing()) {
            releaseReservationLockIfSafe("onDestroy_finishing");
        }
        super.onDestroy();
    }

    private void setTextOrDash(TextView tv, String val) {
        if (tv == null) return;
        if (val == null || val.trim().isEmpty() || val.trim().equals("0"))
            tv.setText("-");
        else
            tv.setText(val);
    }

    private void setupSystemBarScrims() {
        Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);

        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);

        WindowInsetsControllerCompat controller =
                new WindowInsetsControllerCompat(window, window.getDecorView());
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);

        View statusScrim = findViewById(R.id.status_bar_scrim);
        View navScrim    = findViewById(R.id.navigation_bar_scrim);
        View root        = findViewById(R.id.root_container);

        if (root == null || statusScrim == null || navScrim == null) return;

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets statusBars = insets.getInsets(WindowInsetsCompat.Type.statusBars());
            Insets navBars    = insets.getInsets(WindowInsetsCompat.Type.navigationBars());

            ViewGroup.LayoutParams lpTop = statusScrim.getLayoutParams();
            if (lpTop.height != statusBars.top) {
                lpTop.height = statusBars.top;
                statusScrim.setLayoutParams(lpTop);
            }
            statusScrim.setBackgroundColor(Color.BLACK);
            statusScrim.setVisibility(statusBars.top > 0 ? View.VISIBLE : View.GONE);

            ViewGroup.LayoutParams lpBottom = navScrim.getLayoutParams();
            if (lpBottom.height != navBars.bottom) {
                lpBottom.height = navBars.bottom;
                navScrim.setLayoutParams(lpBottom);
            }
            navScrim.setBackgroundColor(Color.BLACK);
            navScrim.setVisibility(navBars.bottom > 0 ? View.VISIBLE : View.GONE);

            return WindowInsetsCompat.CONSUMED;
        });

        root.requestApplyInsets();
    }

    private void setRowVisibility(View v, boolean visible) {
        if (v != null) v.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    /* ---------------- Confirm dialog with UPI ---------------- */

    private void showConfirmWithUpiDialog() {
        View content = LayoutInflater.from(this).inflate(R.layout.dialog_upi_capture, null, false);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) EditText etUpi = content.findViewById(R.id.et_upi);

        String msg = "Are you sure?\n\nBooking appointment charge will be ₹" +
                String.format(Locale.getDefault(), "%.0f", DEPOSIT) + " if you cancel.\n\n" +
                "Please enter your refund UPI ID (e.g., name@bank).";

        d("UPI dialog opened. Deposit(Platform Charge)=" + fmt2(DEPOSIT));

        new AlertDialog.Builder(pending_bill.this)
                .setTitle("Confirm Appointment")
                .setMessage(msg)
                .setView(content)
                .setCancelable(false)
                .setPositiveButton("Proceed", (dialog, which) -> {
                    Editable ed = etUpi.getText();
                    String vpa = (ed == null) ? "" : ed.toString().trim();

                    d("UPI entered (masked)=" + maskUpi(vpa) + " length=" + vpa.length());

                    if (!isLikelyValidUpi(vpa)) {
                        w("UPI failed local validation (masked)=" + maskUpi(vpa));
                        Toast.makeText(this, "Please enter a valid UPI like name@bank", Toast.LENGTH_LONG).show();
                        return;
                    }

                    d("UPI passed local validation. Verifying with backend...");
                    verifyUpi(vpa, () -> continueAfterUpiVerified(vpa));
                })
                .setNegativeButton("Cancel", (d, w) -> {
                    d("UPI dialog cancelled by user");
                    d.dismiss();
                })
                .show();
    }

    private boolean isLikelyValidUpi(String vpa) {
        if (TextUtils.isEmpty(vpa)) return false;
        if (vpa.length() < 6 || vpa.length() > 300) return false;
        if (vpa.contains(" ") || vpa.contains("\\") || vpa.contains("/")) return false;
        return vpa.matches("^[a-zA-Z0-9._\\-]{2,256}@[a-zA-Z]{3,64}$");
    }

    private void verifyUpi(String vpa, Runnable onSuccess) {
        if (!isFinishing() && !isDestroyed()) loaderutil.showLoader(this);

        d("verifyUpi() POST -> " + upiVerifyUrl + " vpa(masked)=" + maskUpi(vpa));

        StringRequest req = new StringRequest(
                Request.Method.POST,
                upiVerifyUrl,
                resp -> {
                    d("verifyUpi() response=" + resp);
                    try {
                        JSONObject o = new JSONObject(resp);
                        boolean ok = o.optBoolean("valid", false);
                        String msg = o.optString("message", "");
                        d("verifyUpi() parsed: valid=" + ok + ", message=" + msg);

                        if (!ok) {
                            loaderutil.hideLoader();
                            Toast.makeText(this, (msg.isEmpty() ? "UPI not supported" : msg), Toast.LENGTH_LONG).show();
                        } else {
                            if (onSuccess != null) onSuccess.run();
                        }
                    } catch (Exception e) {
                        loaderutil.hideLoader();
                        e("UPI verification parse error.", e);
                        Toast.makeText(this, "UPI verification parse error.", Toast.LENGTH_LONG).show();
                    }
                },
                err -> {
                    loaderutil.hideLoader();
                    e("verifyUpi() network error", err);
                    Toast.makeText(this, "Network error during UPI verification.", Toast.LENGTH_LONG).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("vpa", vpa);
                p.put("_ts", String.valueOf(System.currentTimeMillis()));
                return p;
            }
        };
        req.setShouldCache(false);
        req.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.5f));
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void continueAfterUpiVerified(String vpa) {
        enteredUpiId = vpa;
        d("UPI verified OK. enteredUpiId(masked)=" + maskUpi(enteredUpiId));

        if (selectedPaymentMethod == null || selectedPaymentMethod.isEmpty()) {
            loaderutil.hideLoader();
            Toast.makeText(this, "Please choose a payment option to continue.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Phase 3: one authoritative server quote before any money action.
        fetchAuthoritativeBookingQuote(true);
    }

    private void fetchAuthoritativeBookingQuote(boolean continueAfterLoad) {
        if (userLat == 0.0 && userLng == 0.0) {
            loaderutil.hideLoader();
            Toast.makeText(this, "Booking location is not ready yet. Please try again.", Toast.LENGTH_LONG).show();
            return;
        }
        loaderutil.showLoader(this);
        StringRequest req = new StringRequest(Request.Method.POST, bookingQuoteUrl,
                resp -> {
                    try {
                        JSONObject root = new JSONObject(resp);
                        if (!root.optBoolean("success")) {
                            loaderutil.hideLoader();
                            Toast.makeText(this, root.optString("message", "Unable to calculate booking price."), Toast.LENGTH_LONG).show();
                            return;
                        }
                        JSONObject q = root.getJSONObject("quote");
                        bookingQuoteToken = q.optString("quote_token", "");
                        if (bookingQuoteToken.isEmpty()) throw new JSONException("Missing quote token");
                        APPOINTMENT_CHARGE = q.getDouble("appointment_charge");
                        consultingFee      = q.getDouble("consultation_fee");
                        DEPOSIT            = q.getDouble("platform_charge");
                        GST_PERCENT        = q.getDouble("gst_percent");
                        gstAmount          = q.getDouble("gst");
                        FREE_DISTANCE_KM   = q.getDouble("base_distance");
                        PER_KM_CHARGE      = q.getDouble("extra_cost_per_km");
                        distanceKm         = q.getDouble("distance");
                        distanceCharge     = q.getDouble("distance_charge");
                        vaccinationPrice   = q.optDouble("vaccination_price", 0.0);
                        String serverVaccineName = q.optString("vaccination_name", "");
                        if (!serverVaccineName.isEmpty()) vaccinationName = serverVaccineName;
                        walletBalance      = q.getDouble("wallet_balance");
                        finalCost          = q.getDouble("final_exact");
                        finalPayRupees     = q.getLong("gateway_rupees");
                        lastConfirmedDepositMode = "Wallet Debited".equalsIgnoreCase(q.optString("deposit_status"))
                                ? DepositMode.WALLET : DepositMode.BILL;
                        cfgLoaded = true;
                        chargeLoaded = true;
                        distanceReady = true;
                        recomputeTotalsAndUI();
                        if (continueAfterLoad) {
                            continueWithAuthoritativeQuote();
                        } else {
                            loaderutil.hideLoader();
                        }
                    } catch (Exception ex) {
                        loaderutil.hideLoader();
                        e("Authoritative quote parse error", ex);
                        Toast.makeText(this, "Could not verify booking price. Please try again.", Toast.LENGTH_LONG).show();
                    }
                },
                err -> {
                    loaderutil.hideLoader();
                    e("Authoritative quote network error", err);
                    Toast.makeText(this, "Could not verify booking price. Please check your connection.", Toast.LENGTH_LONG).show();
                }) {
            @Override protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("patient_id", patientId);
                p.put("doctor_id", doctorId);
                p.put("user_lat", String.valueOf(userLat));
                p.put("user_lng", String.valueOf(userLng));
                p.put("is_vet_case", String.valueOf(isVetCase));
                p.put("booking_status", status == null ? "Pending" : status);
                if (reservationToken != null && !reservationToken.isEmpty()) {
                    p.put("reservation_token", reservationToken);
                }
                if (animalCategoryId != null && !animalCategoryId.trim().isEmpty()) p.put("animal_category_id", animalCategoryId);
                if (vaccinationId != null && !vaccinationId.trim().isEmpty()) p.put("vaccination_id", vaccinationId);
                return p;
            }
        };
        req.setShouldCache(false);
        req.setRetryPolicy(new DefaultRetryPolicy(15000, 1, 1.5f));
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void continueWithAuthoritativeQuote() {
        if ("Offline".equals(selectedPaymentMethod) && lastConfirmedDepositMode != DepositMode.WALLET) {
            loaderutil.hideLoader();
            Toast.makeText(this, "Wallet में ₹" + (int) DEPOSIT + " होने पर ही Offline booking होगी.", Toast.LENGTH_LONG).show();
            return;
        }

        if ("Offline".equals(selectedPaymentMethod)) {
            setDepositLine("Platform Charge will be debited safely during booking: ₹" + (int) DEPOSIT, true);
            paymentStarted = true;
            saveBookingData(googleMapsLink);
        } else {
            if (lastConfirmedDepositMode == DepositMode.WALLET) {
                setDepositLine("Wallet will be debited safely after payment verification: ₹" + (int) DEPOSIT, true);
            } else {
                setDepositLine("Platform Charge added to bill: ₹" + (int) DEPOSIT, true);
            }
            paymentStarted = true;
            startPhonePeCheckout();
        }
    }

    /* ---------------- PhonePe ---------------- */

    private void startPhonePeCheckout() {
        if (bookingQuoteToken == null || bookingQuoteToken.isEmpty()) {
            loaderutil.hideLoader();
            Toast.makeText(this, "Booking price expired. Please try again.", Toast.LENGTH_LONG).show();
            return;
        }
        d("startPhonePeCheckout() -> " + ppCreateOrderUrl);
        d("Gateway amount alignment: finalPayRupees=" + finalPayRupees + " => paise=" + (finalPayRupees * 100L));
        logBillingState("startPhonePeCheckout");

        StringRequest req = new StringRequest(
                Request.Method.POST,
                ppCreateOrderUrl,
                resp -> {
                    d("create_order response=" + resp);
                    try {
                        JSONObject obj = new JSONObject(resp);
                        if (!"success".equalsIgnoreCase(obj.optString("status"))) {
                            loaderutil.hideLoader();
                            Toast.makeText(this, "Failed to create order.", Toast.LENGTH_SHORT).show();
                            Log.e(TAG, "create_order failed: " + obj);
                            return;
                        }

                        ppMerchantOrderId = obj.optString("merchantOrderId", null);
                        String token   = obj.optString("token", "");
                        String orderId = obj.optString("orderId", "");

                        d("create_order parsed: merchantOrderId=" + ppMerchantOrderId
                                + ", tokenLen=" + token.length()
                                + ", orderId=" + orderId);

                        if (ppMerchantOrderId == null || token.isEmpty() || orderId.isEmpty()) {
                            loaderutil.hideLoader();
                            Toast.makeText(this, "Invalid order response.", Toast.LENGTH_SHORT).show();
                            Log.e(TAG, "Missing token/orderId/merchantOrderId: " + obj);
                            return;
                        }

                        PhonePeKt.startCheckoutPage(this, token, orderId, ppCheckoutLauncher);

                    } catch (Exception e) {
                        loaderutil.hideLoader();
                        e("create_order parse error", e);
                        Toast.makeText(this, "Order parse error.", Toast.LENGTH_SHORT).show();
                    }
                },
                err -> {
                    loaderutil.hideLoader();
                    e("create_order network error", err);
                    Toast.makeText(this, "Network error creating order.", Toast.LENGTH_SHORT).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("patient_id", patientId);
                long paise = finalPayRupees * 100L;
                p.put("amount", String.valueOf(paise));
                p.put("purpose", "APPOINTMENT");
                p.put("quote_token", bookingQuoteToken);
                p.put("_ts", String.valueOf(System.currentTimeMillis()));
                d("create_order params: patient_id=" + safe(patientId) + ", amount(paise)=" + paise + ", purpose=APPOINTMENT");
                return p;
            }
        };
        req.setShouldCache(false);
        req.setRetryPolicy(new DefaultRetryPolicy(15000, 1, 1.5f));
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void checkPhonePeStatus(String merchantOrderId) {
        final Handler h = new Handler(getMainLooper());
        final int[] attempts = {0};
        final int maxAttempts = 5;

        d("checkPhonePeStatus() start merchantOrderId=" + merchantOrderId + " maxAttempts=" + maxAttempts);

        Runnable check = new Runnable() {
            @Override public void run() {
                if (isFinishing() || isDestroyedOrFinishing || isDestroyed()) {
                    loaderutil.hideLoader();
                    w("checkPhonePeStatus() aborted due to lifecycle");
                    return;
                }

                attempts[0]++;
                String url = ppStatusUrl + "?merchantOrderId=" + Uri.encode(merchantOrderId) + "&skipWallet=1&ts=" + System.currentTimeMillis();
                d("checkPhonePeStatus() attempt " + attempts[0] + "/" + maxAttempts + " GET -> " + url);

                StringRequest req = new StringRequest(Request.Method.GET, url,
                        resp -> {
                            d("check_status response=" + resp);
                            try {
                                JSONObject obj = new JSONObject(resp);

                                String topStatus = obj.optString("status");
                                if (!"success".equalsIgnoreCase(topStatus) && !"ok".equalsIgnoreCase(topStatus)) {
                                    w("check_status top status not success/ok: " + topStatus);
                                    if (attempts[0] < maxAttempts) {
                                        h.postDelayed(this, 2000);
                                        return;
                                    }
                                    loaderutil.hideLoader();
                                    Toast.makeText(pending_bill.this, "Could not verify payment right now. Please try again.", Toast.LENGTH_LONG).show();
                                    return;
                                }

                                String state = obj.optString("state", "PENDING");
                                d("check_status parsed state=" + state + ", selectedPaymentMethod=" + selectedPaymentMethod);

                                if ("COMPLETED".equalsIgnoreCase(state)) {
                                    // Wallet debit now happens atomically in save_appointment.php.
                                    fetchWalletBalance();

                                    Toast.makeText(pending_bill.this, "Payment successful.", Toast.LENGTH_SHORT).show();
                                    d("PhonePe COMPLETED, merchantOrderId=" + ppMerchantOrderId);
                                    loaderutil.hideLoader();

                                    logBillingState("before_saveBookingData_online_completed");
                                    saveBookingData(googleMapsLink);

                                } else if ("FAILED".equalsIgnoreCase(state)) {
                                    loaderutil.hideLoader();
                                    Toast.makeText(pending_bill.this, "Payment failed.", Toast.LENGTH_SHORT).show();
                                    w("PhonePe FAILED for merchantOrderId=" + merchantOrderId);

                                } else {
                                    if (attempts[0] < maxAttempts) {
                                        h.postDelayed(this, 2000);
                                    } else {
                                        loaderutil.hideLoader();
                                        Toast.makeText(pending_bill.this, "Payment pending. You can check again from history.", Toast.LENGTH_SHORT).show();
                                        w("PhonePe state still " + state + " after max attempts");
                                    }
                                }
                            } catch (Exception e) {
                                e("Status parse error", e);
                                if (attempts[0] < maxAttempts) {
                                    h.postDelayed(this, 2000);
                                } else {
                                    loaderutil.hideLoader();
                                    Toast.makeText(pending_bill.this, "Status parse error.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        err -> {
                            e("Server error while checking status.", err);
                            if (attempts[0] < maxAttempts) {
                                h.postDelayed(this, 2000);
                            } else {
                                loaderutil.hideLoader();
                                Toast.makeText(pending_bill.this, "Server error while checking status.", Toast.LENGTH_SHORT).show();
                            }
                        });
                req.setShouldCache(false);
                req.setRetryPolicy(new DefaultRetryPolicy(15000, 1, 1.5f));
                VolleySingleton.getInstance(pending_bill.this).getRequestQueue().add(req);
            }
        };

        if (!isFinishing() && !isDestroyed()) loaderutil.showLoader(this);
        check.run();
    }

    /* ---------------- Config & distance ---------------- */

    private void fetchAppConfig() {
        String url = ApiConfig.endpoint("get_app_config.php") + "?ts=" + System.currentTimeMillis();
        d("fetchAppConfig() GET -> " + url);

        @SuppressLint("DefaultLocale") JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                resp -> {
                    d("fetchAppConfig() response=" + resp);
                    if (!resp.optBoolean("success")) {
                        String err = resp.optString("error", "CONFIG_FAILED");
                        loaderutil.hideLoader();
                        Toast.makeText(this, "Config error: " + err, Toast.LENGTH_LONG).show();
                        w("Config error: " + err);
                        finish();
                        return;
                    }

                    FREE_DISTANCE_KM = resp.optDouble("base_distance");
                    PER_KM_CHARGE    = resp.optDouble("extra_cost_per_km");
                    DEPOSIT          = resp.optDouble("platform_charge");
                    GST_PERCENT      = resp.optDouble("gst_percent");
                    cfgLoaded = true;

                    d("Config loaded: base_distance=" + fmt2(FREE_DISTANCE_KM)
                            + ", extra_cost_per_km=" + fmt2(PER_KM_CHARGE)
                            + ", platform_charge=" + fmt2(DEPOSIT)
                            + ", gst_percent=" + fmt2(GST_PERCENT));

                    tvPricePerKm.setText(String.format("₹ %.2f per kilometer", PER_KM_CHARGE));
                    fetchAppointmentCharge(doctorId);
                    logBillingState("after_fetchAppConfig");
                },
                err -> {
                    loaderutil.hideLoader();
                    e("Network error fetching config", err);
                    Toast.makeText(this, "Config network error", Toast.LENGTH_LONG).show();
                    finish();
                }
        );
        req.setShouldCache(false);
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void fetchAppointmentCharge(String doctorId) {
        String url = ApiConfig.endpoint("get_appointment_charge.php", "doctor_id", doctorId) + "&ts=" + System.currentTimeMillis();
        d("fetchAppointmentCharge() GET -> " + url);

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    d("fetchAppointmentCharge() response=" + response);

                    if (response.optBoolean("success")) {
                        APPOINTMENT_CHARGE = response.optDouble("appointment_charge", 250.0);
                    } else {
                        APPOINTMENT_CHARGE = 250.0;
                    }

                    gstAmount     = APPOINTMENT_CHARGE * (GST_PERCENT / 100.0);
                    consultingFee = APPOINTMENT_CHARGE - DEPOSIT;
                    chargeLoaded  = true;

                    d("Charge loaded: APPOINTMENT_CHARGE=" + fmt2(APPOINTMENT_CHARGE)
                            + ", GST_PERCENT=" + fmt2(GST_PERCENT) + " => gstAmount=" + fmt2(gstAmount)
                            + ", DEPOSIT=" + fmt2(DEPOSIT) + " => consultingFee=" + fmt2(consultingFee));

                    recomputeTotalsAndUI();
                    logBillingState("after_fetchAppointmentCharge");
                },
                error -> {
                    e("Volley error fetching doctor charge", error);

                    APPOINTMENT_CHARGE = 250.0;
                    gstAmount     = APPOINTMENT_CHARGE * (GST_PERCENT / 100.0);
                    consultingFee = APPOINTMENT_CHARGE - DEPOSIT;
                    chargeLoaded  = true;

                    d("Charge fallback: APPOINTMENT_CHARGE=" + fmt2(APPOINTMENT_CHARGE)
                            + ", gstAmount=" + fmt2(gstAmount)
                            + ", consultingFee=" + fmt2(consultingFee));

                    recomputeTotalsAndUI();
                    logBillingState("after_fetchAppointmentCharge_errorFallback");
                }
        );
        req.setShouldCache(false);
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void fetchDoctorLocation(String docId) {
        String url = ApiConfig.endpoint("get_doctor_location.php", "doctor_id", docId) + "&ts=" + System.currentTimeMillis();
        d("fetchDoctorLocation() GET -> " + url);

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                resp -> {
                    d("fetchDoctorLocation() response=" + resp);
                    try {
                        if (resp.getBoolean("success")) {
                            String loc = resp.getString("location");
                            d("Doctor location string=" + loc);
                            parseDoctorLatLng(loc);
                        } else {
                            w("fetchDoctorLocation(): success=false.");
                            handleDistanceFailure("Doctor location is unavailable.");
                        }
                    } catch (JSONException e) {
                        e("fetchDoctorLocation() JSON parse error", e);
                        handleDistanceFailure("Doctor location could not be read.");
                    }
                },
                err -> {
                    e("fetchDoctorLocation() network error", err);
                    handleDistanceFailure("Could not calculate travel distance.");
                }
        );
        req.setShouldCache(false);
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void parseDoctorLatLng(String docUrl) {
        try {
            Uri uri = Uri.parse(docUrl);
            String q = uri.getQueryParameter("query");
            d("parseDoctorLatLng(): parsed query=" + q);

            if (q != null && q.contains(",")) {
                String[] p = q.split(",");
                docLat = Double.parseDouble(p[0]);
                docLng = Double.parseDouble(p[1]);
                d("Doctor lat/lng parsed: " + docLat + "," + docLng);

                if (userLat != 0.0 && userLng != 0.0 && docLat != 0.0 && docLng != 0.0) {
                    fetchDrivingDistance(userLat, userLng, docLat, docLng);
                } else {
                    w("Cannot fetch distance: missing coords. userLatLng=" + userLat + "," + userLng + " docLatLng=" + docLat + "," + docLng);
                    handleDistanceFailure("Booking location is incomplete.");
                }
            } else {
                w("parseDoctorLatLng(): query missing/invalid in docUrl.");
                handleDistanceFailure("Doctor location is invalid.");
            }
        } catch (Exception e) {
            e("parseDoctorLatLng() error", e);
            handleDistanceFailure("Doctor location is invalid.");
        }
    }

    private void fetchDrivingDistance(double lat1, double lng1, double lat2, double lng2) {
        logDirectionsRequest(lat1, lng1, lat2, lng2);

        // PRIMARY: Backend route endpoint — API key stays on server.
        String url = ApiConfig.endpoint(
                "get_route_distance.php",
                "origin_lat", String.valueOf(lat1),
                "origin_lng",  String.valueOf(lng1),
                "destination_lat", String.valueOf(lat2),
                "destination_lng", String.valueOf(lng2),
                "mode", "driving"
        ) + "&ts=" + System.currentTimeMillis();

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    boolean success = response.optBoolean("success", false);
                    if (success) {
                        parseRoutesResponse(response);
                    } else {
                        w("Backend route API returned success=false: " + response.optString("message", ""));
                        handleDistanceFailure("Route could not be calculated. Please try again.");
                    }
                },
                err -> {
                    e("Backend route distance network error", err);
                    handleDistanceFailure("Route service is temporarily unavailable.");
                }
        );
        req.setShouldCache(false);
        req.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(8000, 1, 1.0f));
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    private void handleDistanceFailure(String message) {
        distanceReady = false;
        distanceKm = 0.0;
        distanceCharge = 0.0;
        disablePayButton();
        loaderutil.hideLoader();
        if (!isFinishing() && !isDestroyed()) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    @SuppressLint("SetTextI18n")
    private void parseRoutesResponse(JSONObject response) {
        d("parseRoutesResponse() raw=" + response);
        try {
            boolean success = response.optBoolean("success", false);
            if (success) {
                long meters = response.optLong("distance_meters", 0L);
                distanceKm  = meters / 1000.0;

                d("Distance parsed from backend: meters=" + meters + " => distanceKm=" + fmt2(distanceKm)
                        + ", FREE_DISTANCE_KM=" + fmt2(FREE_DISTANCE_KM)
                        + ", PER_KM_CHARGE=" + fmt2(PER_KM_CHARGE));

                if (distanceKm <= FREE_DISTANCE_KM) {
                    distanceCharge = 0.0;
                    tvDistanceChargeValue.setText("Free under " + String.format(Locale.getDefault(),"%.0f", FREE_DISTANCE_KM) + " km");
                    d("Distance charge: FREE (<= base distance)");
                } else {
                    distanceCharge = distanceKm * PER_KM_CHARGE;
                    tvDistanceChargeValue.setText(String.format(Locale.getDefault(), "₹ %.0f", distanceCharge));
                    d("Distance charge computed: distanceKm(" + fmt2(distanceKm) + ") * perKm(" + fmt2(PER_KM_CHARGE) + ") = " + fmt2(distanceCharge));
                }
            } else {
                w("Route backend failed: " + response.optString("message", "No route found")
                        + " raw_status=" + response.optString("raw_status", ""));
            }
        } catch (Exception e) {
            e("Routes parse error", e);
        }
        distanceReady = true;
        recomputeTotalsAndUI();
        logBillingState("after_parseRoutesResponse");
    }
    /* ---------------- UI recompute ---------------- */

    @SuppressLint("SetTextI18n")
    private void recomputeTotalsAndUI() {
        boolean ready = cfgLoaded && chargeLoaded && distanceReady;

        double distanceChargeRaw = (distanceKm <= FREE_DISTANCE_KM) ? 0.0 : (distanceKm * PER_KM_CHARGE);
        distanceCharge = distanceChargeRaw;

        // Base total (consulting + GST + distance)
        double baseTotal = consultingFee + gstAmount + distanceChargeRaw;

        // Add vaccination price if any
        boolean addVaccine = (isVetCase == 1 && vaccinationPrice > 0.0);
        if (addVaccine) {
            baseTotal += vaccinationPrice;
            setRowVisibility(rowVaccinationPrice, true);
            if (tvVaccinationPriceValue != null) {
                tvVaccinationPriceValue.setText("₹ " + (int) Math.round(vaccinationPrice));
            }
        } else {
            setRowVisibility(rowVaccinationPrice, false);
        }

        boolean depositCoveredByWallet = walletBalance >= DEPOSIT;
        boolean addDepositToBill = !depositCoveredByWallet;
        String depositLine;

        if ("Offline".equals(selectedPaymentMethod) && walletBalance < DEPOSIT) {
            depositLine = "Offline booking के लिए wallet में ₹" + (int) DEPOSIT + " होना ज़रूरी है.";
        } else if (depositCoveredByWallet) {
            depositLine = "Wallet will be debited: ₹" + (int) DEPOSIT;
        } else {
            depositLine = "Platform Charge added to bill: ₹" + (int) DEPOSIT;
        }

        double finalCostRaw = baseTotal + (addDepositToBill ? DEPOSIT : 0.0);
        finalPayRupees = (long) Math.ceil(finalCostRaw);
        finalCost = finalCostRaw;

        // FULL PRICE BREAKDOWN LOG
        d("PRICE CALC:"
                + " consultingFee=" + fmt2(consultingFee)
                + " + gstAmount=" + fmt2(gstAmount)
                + " + distanceChargeRaw=" + fmt2(distanceChargeRaw)
                + (addVaccine ? (" + vaccinationPrice=" + fmt2(vaccinationPrice)) : "")
                + " => baseTotal=" + fmt2(baseTotal)
                + " | depositCoveredByWallet=" + depositCoveredByWallet
                + " | addDepositToBill=" + addDepositToBill + " (deposit=" + fmt2(DEPOSIT) + ")"
                + " => finalCostRaw=" + fmt2(finalCostRaw)
                + " => finalPayRupees(ceil)=" + finalPayRupees);

        tvAppointmentCharge.setText("₹ " + (int) APPOINTMENT_CHARGE);
        tvConsultingFeeValue.setText("₹ " + (int) consultingFee);
        tvDistanceKmValue.setText(String.format(Locale.getDefault(),"%.1f km", distanceKm));
        tvGstValue.setText("₹ " + (int) gstAmount);
        tvDistanceChargeValue.setText(distanceChargeRaw > 0
                ? "₹ " + (int) Math.round(distanceChargeRaw)
                : "Free under " + (int) FREE_DISTANCE_KM + " km");
        tvTotalPaidValue.setText("₹ " + finalPayRupees);
        tvWalletBalance.setText("₹" + String.format(Locale.getDefault(),"%.2f", walletBalance));

        if (depositLine.isEmpty()) hideDepositRow(); else showDepositRow(depositLine);

        if ("Offline".equals(selectedPaymentMethod) && walletBalance < DEPOSIT) {
            btnRechargeWallet.setVisibility(View.VISIBLE);
            disablePayButton();
        } else {
            btnRechargeWallet.setVisibility(View.GONE);
            if (!ready) {
                disablePayButton();
                if (!isFinishing() && !isDestroyed()) loaderutil.showLoader(this);
            } else {
                loaderutil.hideLoader();
                enablePayButton();
            }
        }

        boolean canUseOffline = walletBalance >= DEPOSIT;
        btnOfflinePayment.setAlpha(canUseOffline ? 1f : 0.7f);

        // Always log after recompute
        logBillingState("recomputeTotalsAndUI");
    }

    private void hideDepositRow() {
        if (depositRow != null) depositRow.setVisibility(View.GONE);
        if (depositLabelView != null) depositLabelView.setVisibility(View.GONE);
        if (tvDeposit != null) {
            tvDeposit.setText("");
            tvDeposit.setVisibility(View.GONE);
        }
    }

    private void showDepositRow(String text) {
        if (depositLabelView != null) depositLabelView.setVisibility(View.GONE);
        if (depositRow != null) depositRow.setVisibility(View.VISIBLE);
        if (tvDeposit != null) {
            tvDeposit.setVisibility(View.VISIBLE);
            tvDeposit.setSingleLine(false);
            tvDeposit.setMaxLines(3);
            tvDeposit.setEllipsize(null);
            tvDeposit.setText(text);
        }
        d("Deposit line UI: " + text);
    }

    private void setDepositLine(String text, boolean show) {
        if (show) showDepositRow(text); else hideDepositRow();
    }

    private void setButtonNeutralState() {
        int gray = getResources().getColor(R.color.custom_gray);
        btnOnlinePayment.setBackgroundColor(gray);
        btnOfflinePayment.setBackgroundColor(gray);
        payButton.setBackgroundColor(gray);
        payButton.setAlpha(0.5f);
    }

    private void stylePaymentButtons() {
        int cyan = getResources().getColor(R.color.dark_cyan);
        int gray = getResources().getColor(R.color.custom_gray);
        if ("Online".equals(selectedPaymentMethod)) {
            btnOnlinePayment.setBackgroundColor(cyan);
            btnOfflinePayment.setBackgroundColor(gray);
        } else if ("Offline".equals(selectedPaymentMethod)) {
            btnOfflinePayment.setBackgroundColor(cyan);
            btnOnlinePayment.setBackgroundColor(gray);
        } else {
            setButtonNeutralState();
        }
    }

    /* ---------------- Wallet ---------------- */

    private void fetchWalletBalance() {
        String url = ApiConfig.endpoint("get_wallet_balance.php");
        d("fetchWalletBalance() POST -> " + url + " patientId=" + safe(patientId));

        @SuppressLint("SetTextI18n") StringRequest req = new StringRequest(Request.Method.POST, url,
                resp -> {
                    d("fetchWalletBalance() response=" + resp);
                    try {
                        JSONObject obj = new JSONObject(resp);
                        if ("success".equals(obj.optString("status"))) {
                            double old = walletBalance;
                            walletBalance = obj.optDouble("wallet_balance", 0.0);
                            d("Wallet balance updated: " + fmt2(old) + " -> " + fmt2(walletBalance));
                            tvWalletBalance.setText("₹" + String.format(Locale.getDefault(),"%.2f", walletBalance));
                            recomputeTotalsAndUI();
                        } else {
                            w("fetchWalletBalance(): status=" + obj.optString("status"));
                        }
                    } catch (JSONException e) {
                        e("fetchWalletBalance() parse error", e);
                    }
                },
                err -> e("Wallet fetch error", err)
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("patient_id", patientId);
                p.put("_ts", String.valueOf(System.currentTimeMillis()));
                return p;
            }
        };
        req.setShouldCache(false);
        req.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.5f));
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    /* ---------------- Save booking ---------------- */

    private void saveBookingData(String googleMapsLink) {
        String url = ApiConfig.endpoint("save_appointment.php");
        d("saveBookingData() POST -> " + url);
        d("saveBookingData() location=" + safe(googleMapsLink) + " userLatLng=" + userLat + "," + userLng);
        d("saveBookingData() reservationToken=" + (reservationToken.isEmpty() ? "(none)" : "[present]"));
        logBillingState("saveBookingData_start");
        appointmentSaveInProgress = true; // block lock release while HTTP is in flight

        StringRequest req = new StringRequest(Request.Method.POST, url,
                resp -> {
                    d("saveBookingData() response=" + resp);
                    try {
                        JSONObject r = new JSONObject(resp);

                        // Handle reservation/lock errors from server
                        String code = r.optString("code", "");
                        if ("RESERVATION_EXPIRED".equals(code)) {
                            loaderutil.hideLoader();
                            w("saveBookingData(): RESERVATION_EXPIRED");
                            new androidx.appcompat.app.AlertDialog.Builder(pending_bill.this)
                                    .setTitle("Reservation Expired")
                                    .setMessage(r.optString("message",
                                            "Your doctor reservation expired. Please check availability again."))
                                    .setPositiveButton("OK", (dlg, which) -> finish())
                                    .setCancelable(false)
                                    .show();
                            return;
                        }
                        if ("RESERVATION_REQUIRED".equals(code)) {
                            loaderutil.hideLoader();
                            w("saveBookingData(): RESERVATION_REQUIRED");
                            new androidx.appcompat.app.AlertDialog.Builder(pending_bill.this)
                                    .setTitle("Booking Unavailable")
                                    .setMessage(r.optString("message",
                                            "Please check doctor availability again before booking."))
                                    .setPositiveButton("OK", (dlg, which) -> finish())
                                    .setCancelable(false)
                                    .show();
                            return;
                        }
                        if ("DOCTOR_BUSY".equals(code)) {
                            loaderutil.hideLoader();
                            w("saveBookingData(): DOCTOR_BUSY");
                            Toast.makeText(pending_bill.this,
                                    r.optString("message",
                                            "This doctor is currently being booked by another patient."),
                                    Toast.LENGTH_LONG).show();
                            finish();
                            return;
                        }

                        boolean success = r.optBoolean("success", false);
                        String appointmentId = r.optString("appointment_id", "0");

                        if (!success || appointmentId.equals("0")) {
                            loaderutil.hideLoader();
                            String errMsg = r.optString("error",
                                    r.optString("message", "Could not book your appointment."));
                            Toast.makeText(pending_bill.this, errMsg, Toast.LENGTH_LONG).show();
                            e("saveBookingData() server returned failure: " + resp, null);
                            return;
                        }

                        appointmentConfirmed = true;
                        appointmentSaveInProgress = false;
                        boolean paymentRecorded = r.optBoolean("payment_recorded", false);
                        if (paymentRecorded) {
                            loaderutil.hideLoader();
                            JSONObject billing = r.optJSONObject("billing");
                            if (billing != null) walletBalance = billing.optDouble("wallet_balance_after", billing.optDouble("wallet_balance", walletBalance));
                            Toast.makeText(this, "Appointment booked successfully.", Toast.LENGTH_SHORT).show();
                            onBookingSuccess();
                        } else {
                            // New APK never writes money from the client. If the backend was not
                            // deployed first, stop here instead of falling back to client-authoritative
                            // payment_history.php values.
                            loaderutil.hideLoader();
                            appointmentSaveInProgress = false;
                            Toast.makeText(this,
                                    "Booking server update is incomplete. Please try again shortly.",
                                    Toast.LENGTH_LONG).show();
                            e("Atomic booking response missing payment_recorded=true", null);
                        }
                    } catch (JSONException e) {
                        loaderutil.hideLoader();
                        e("saveBookingData() parse error", e);
                    }
                },
                err -> {
                    loaderutil.hideLoader();
                    appointmentSaveInProgress = false; // save failed; allow back-press release
                    e("saveBookingData() network error", err);
                    // Check if it's an HTTP 409 (reservation expired / doctor busy)
                    if (err.networkResponse != null && err.networkResponse.statusCode == 409) {
                        try {
                            String body = new String(err.networkResponse.data);
                            JSONObject errObj = new JSONObject(body);
                            String errCode = errObj.optString("code", "");
                            String errMsg  = errObj.optString("message", "Could not book your appointment.");
                            if ("RESERVATION_EXPIRED".equals(errCode)) {
                                new androidx.appcompat.app.AlertDialog.Builder(pending_bill.this)
                                        .setTitle("Reservation Expired")
                                        .setMessage(errMsg)
                                        .setPositiveButton("OK", (dlg, which) -> finish())
                                        .setCancelable(false)
                                        .show();
                                return;
                            } else {
                                Toast.makeText(this, errMsg, Toast.LENGTH_LONG).show();
                                finish();
                                return;
                            }
                        } catch (Exception ignored) {}
                    }
                    new androidx.appcompat.app.AlertDialog.Builder(pending_bill.this)
                            .setTitle("Booking confirmation interrupted")
                            .setMessage("Your payment/booking request may already have reached the server. Retry confirmation safely with the same booking reference?")
                            .setNegativeButton("Later", null)
                            .setPositiveButton("Retry", (dlg, which) -> {
                                loaderutil.showLoader(pending_bill.this);
                                saveBookingData(googleMapsLink);
                            })
                            .show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("patient_id", patientId);
                p.put("patient_name", patientName);
                p.put("age", patientAge);
                p.put("gender", patientGender);
                p.put("address", patientAddress);
                p.put("doctor_id", doctorId);
                p.put("reason_for_visit", patientProblem);

                Date now = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                p.put("appointment_date", dateFormat.format(now));
                p.put("time_slot", timeFormat.format(now));
                p.put("pincode", pincode);
                p.put("appointment_mode", "Online");
                p.put("payment_method", selectedPaymentMethod);
                p.put("status", status);
                p.put("location", googleMapsLink);
                p.put("atomic_billing", "1");
                p.put("quote_token", bookingQuoteToken == null ? "" : bookingQuoteToken);
                p.put("user_lat", String.valueOf(userLat));
                p.put("user_lng", String.valueOf(userLng));
                p.put("upi_id", enteredUpiId == null ? "" : enteredUpiId);
                if (ppMerchantOrderId != null && !ppMerchantOrderId.isEmpty()) p.put("payment_reference", ppMerchantOrderId);

                // ── Reservation token (required for lock confirmation) ──────────────
                if (!reservationToken.isEmpty()) {
                    p.put("reservation_token", reservationToken);
                }

                p.put("is_vet_case", String.valueOf(isVetCase));
                if (isVetCase == 1) {
                    if (animalCategoryId != null && !animalCategoryId.trim().isEmpty())
                        p.put("animal_category_id", animalCategoryId);
                    if (animalName != null && !animalName.trim().isEmpty())
                        p.put("animal_name", animalName);
                    if (animalGender != null && !animalGender.trim().isEmpty())
                        p.put("animal_gender", animalGender);
                    if (animalAge != null && !animalAge.trim().isEmpty())
                        p.put("animal_age", animalAge);
                    if (animalBreed != null && !animalBreed.trim().isEmpty())
                        p.put("animal_breed", animalBreed);
                    if (vaccinationId != null && !vaccinationId.trim().isEmpty())
                        p.put("vaccination_id", vaccinationId);
                    if (vaccinationName != null && !vaccinationName.trim().isEmpty())
                        p.put("vaccination_name", vaccinationName);
                }

                d("saveBookingData() params summary:"
                        + " patient_id=" + safe(patientId)
                        + ", doctor_id=" + safe(doctorId)
                        + ", pincode=" + safe(pincode)
                        + ", payment_method=" + safe(selectedPaymentMethod)
                        + ", status=" + safe(status)
                        + ", is_vet_case=" + isVetCase
                        + ", location=" + safe(googleMapsLink));

                return p;
            }
        };
        req.setShouldCache(false);
        req.setRetryPolicy(new DefaultRetryPolicy(15000, 1, 1.5f));
        VolleySingleton.getInstance(this).getRequestQueue().add(req);
    }

    // ── Release reservation lock when user backs out of billing without paying ──
    @Override
    public void onBackPressed() {
        releaseReservationLockIfSafe("onBackPressed");
        super.onBackPressed();
    }


    /**
     * Safe, idempotent lock release.
     * Checks all safety flags before firing any network call.
     * Will NOT release if:
     *   - reservationToken or patientId is empty 
     *   - payment has already started (PhonePe or offline)
     *   - save_appointment.php call is currently in flight
     *   - appointment was already confirmed by server
     *   - release was already sent once
     */
    private void releaseReservationLockIfSafe(String reason) {
        if (reservationToken.isEmpty() || patientId.isEmpty()) return;
        if (paymentStarted)            { d("releaseReservationLockIfSafe blocked: paymentStarted [" + reason + "]");         return; }
        if (appointmentSaveInProgress) { d("releaseReservationLockIfSafe blocked: saveInProgress [" + reason + "]");          return; }
        if (appointmentConfirmed)      { d("releaseReservationLockIfSafe blocked: appointmentConfirmed [" + reason + "]");    return; }
        if (lockReleased)              { d("releaseReservationLockIfSafe blocked: alreadyReleased [" + reason + "]");          return; }

        lockReleased = true; // set before async call to prevent duplicate fires
        d("releaseReservationLockIfSafe: releasing lock, reason=" + reason);
        try {
            StringRequest rel = new StringRequest(
                    Request.Method.POST,
                    ApiConfig.RELEASE_DOCTOR_LOCK,
                    resp -> d("pending_bill lock released [" + reason + "]: " + resp),
                    err  -> w("pending_bill lock release failed (auto-expire ok) [" + reason + "]: " + err)
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> p = new HashMap<>();
                    p.put("reservation_token", reservationToken);
                    p.put("patient_id",        patientId);
                    return p;
                }
            };
            rel.setShouldCache(false);
            VolleySingleton.getInstance(this).getRequestQueue().add(rel);
        } catch (Exception e) {
            w("releaseReservationLockIfSafe exception [" + reason + "]: " + e.getMessage());
        }
    }

    private void onBookingSuccess() {
        d("onBookingSuccess() -> MainActivity open_fragment=2 ongoing_tab=" + (isVetCase == 1 ? 1 : 0));
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("open_fragment", 2);
        i.putExtra("ongoing_tab", (isVetCase == 1 ? 1 : 0));
        startActivity(i);
        finish();
    }

    private void enablePayButton() {
        payButton.setEnabled(true);
        payButton.setAlpha(1f);
        payButton.setBackgroundColor(getResources().getColor(R.color.navy_blue));
        d("Pay button ENABLED");
    }

    private void disablePayButton() {
        payButton.setEnabled(false);
        payButton.setAlpha(0.5f);
        payButton.setBackgroundColor(getResources().getColor(R.color.custom_gray));
        d("Pay button DISABLED");
    }
}

// Last Updated: 2026-09-17 21:51 IST
